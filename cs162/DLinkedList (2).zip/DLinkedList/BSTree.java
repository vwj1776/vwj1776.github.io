
// /**
 // * Write a description of class BSTree here.
 // *
 // * @author (your name)
 // * @version (a version number or a date)
 // */
// public class BSTree<T> 
// {
    // // instance variables - replace the example below with your own
      

    // public static void fileExample(String fileName){ //throws IO exception
        // Scanner s = null;
        // BSTree<Integer> t = new BSTree<>();
        
        // try{
            // s = new Scanner(
                 // new BufferedReader(
                    // new FileReader(fileName)));
            // s.useDelimiter(",\\s*");
            
            // while(s.hasNextInt()){
                // int i = s.nextInt();
                // System.out.println(i);
                // t.insert(i);
                
            // }
        // }
        // catch(IOException e){
            // System.out.println(e.getMessage());
            // return;
        // }
        // finally{
           // if (s !=null){
                // s.close();
            // }
        // }
        
        // System.out.println(t.asList(Order.PREORDER));
        // System.out.println(t.asList(Order.INORDER));
        // System.out.println(t.asList(Order.POSTORDER));
        
        // try{
            // t.writeToFile("nums must be good");
        // }
        // catch(Exception e){
            // System.err.println(e.getMessage());
        // }
    // }
    
    // public void writeToFile(String fileName) throws IOExcteption{
        // BufferedWriter out = null;
        
        // try{
            // out = new BufferedWriter(new FileWriter(fileName));
            // List<T> values = asList(Order.INORDER);
            // for(T value : values){
                // out.write(value.toString());
                // out.newLine();
            // }
        // }
        // catch(IOException e){
            // System.err.println(e.getMessage());
        // }
    // }
// }
