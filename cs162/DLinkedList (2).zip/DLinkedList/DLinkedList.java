//import java.util.Iterator;

/**
 * Write a description of class DLinkedList here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class DLinkedList<E> //implements Iterator
{
    // instance variables - replace the example below with your own
    private Node<E> start = null;
    private int size = 0;

    public static void main(String[] args){
        System.out.println();
        DLinkedList<Integer> list = new DLinkedList<>();
        list.addFirst(new Integer(2));
        list.addFirst(new Integer(3));
        list.addFirst(new Integer(5));
        list.addFirst(new Integer(78));
        list.addFirst(new Integer(245));
        list.addFirst(new Integer(23));
        list.addFirst(new Integer(21));
        list.addFirst(new Integer(2333));

        System.out.println("first)");
        for(int i = 0; i<list.size(); i++){

            System.out.println(" " +  i + " " + list.get(i));
        }

        System.out.println("");
        list.addLast(new Integer(2678));
        System.out.println("last");
        for(int i = 0; i<list.size(); i++){

            System.out.println(" " +  i + " " + list.get(i));
        }

        list.add(3, new Integer(3));
        System.out.println("");
        System.out.println("add (3)");
        for(int i = 0; i<list.size(); i++){

            System.out.println(" " +  i + " " + list.get(i));
        }

        list.deleteFirst();
        System.out.println("");
        System.out.println("delete First");
        for(int i = 0; i<list.size(); i++){

            System.out.println(" " +  i + " " + list.get(i));
        }

        list.deleteLast();
        System.out.println("");
        System.out.println("delete Last");
        for(int i = 0; i<list.size(); i++){

            System.out.println(" " +  i + " " + list.get(i));
        }

        list.delete(3);
        System.out.println("");
        System.out.println("delete 3");
        for(int i = 0; i<list.size(); i++){

            System.out.println(" " +  i + " " + list.get(i));
        }



        System.out.println("read file");
        DLinkedList<Integer> list2 = new DLinkedList<>();
        
        int[] r = list2.readFile("dintegersfromclass.txt");
        
        for(int i = 0; i<r.length; i++){
            list2.addLast(r[i]);
            
        }
        for(int i = 0; i<list2.size(); i++){

            System.out.println(" " +  i + " " + list2.get(i));
        }
        
        System.out.println("Write to file" + " " + "writeTotext.txt" + " " + "8 nums" );
        list2.writeFile("writeTotext.txt", 8);
        
        DLinkedList<Integer> list3 = new DLinkedList<>();
        
        int[] r3 = list3.readFile("writeToText.txt");
        
        for(int i = 0; i<r.length; i++){
            list3.addLast(r3[i]);
            
        }
        for(int i = 0; i<list3.size(); i++){

            System.out.println(" " +  i + " " + list3.get(i));
        }
        
    }
    
    public int[] readFile(String fileName){
        ReadFile read = new ReadFile();
        
        return read.readInts(fileName);
    }
    
    public boolean writeFile(String fileName, int numEntries){
        WriteFile write = new WriteFile();
        
        return write.createFile(fileName, numEntries );
        
    }

    public DLinkedList(){
    }
    
    public String toString() {
        String returnStr = "[";
        
        Node<E> n = getFirst();

        returnStr += n.getData();
        if (getLast() != null) {
            returnStr += ", ";
        }
        for (int i = 0; i < size; i++) {
            n = n.getNext();
            returnStr += n.getData();
            if (i != size - 1) {
                returnStr += ", ";
            }
        }
        returnStr += "]";
        return returnStr;
    }

    public E get(int index){ // return a node
        Node<E> r = null;

        if(index > size){
            System.out.println("Index is out of bounds");
        }
        else{
            r = start;
            for(int i = 0; i<index; i++){
                r = r.getNext();

            }
        }

        return r.getData();
    }

    public Node<E> getNode(int index){ // return a node
        Node<E> r = null;

        if(index > size){
            System.out.println("Index is out of bounds");
        }
        else{
            r = start;
            for(int i = 0; i<index; i++){
                r = r.getNext();

            }
        }

        return r;
    }

    public Node<E> get2(int index){ // return a node
        Node<E> r = null;

        if(index > size){
            System.out.println("Index is out of bounds");
        }
        if(index == 0){
            r = start;
        }
        // if(index == getLast().getData()){

        // }
        if(index > (size/2)){
            r = start;
            for(int i = 0; i<index; i++){
                r = r.getNext();

            }
        }
        else{
            r = getLast();
            for(int i = size; i>index; i--){
                r = r.getNext();

            }
        }
        return r;
    }

    public Node<E> getFirst(){
        return start;
    }

    public Node<E> getLast(){
        return start.getPrevious();

    }

    //for iterator 
    //public E next(){
    //    return  
    //}

    public E add(int index, E e){

        // if(start != null){
        // node.setNext(start);
        // node.setPrevious(start.getPrevious());
        // start.setPrevious(node);

        // }
        // else 
        if(index == 0){
            addFirst(e);
        }
        else if(index == size){
            addLast(e);
        }        
        else{
            Node<E> node = new Node(e);
            if(start == null){
                start = node;
            }
            else{

                Node<E> temp = getNode(index-1);

                node.setNext(temp.getNext());
                node.setPrevious(temp);
                temp.setNext(node);
                node.getNext().setPrevious(node);
            }
            size++;
        }
        return e;
    }

    // public void add2(int index, E e){
    // Node<E> node = new Node(e);
    // // if(start != null){
    // // node.setNext(start);
    // // node.setPrevious(start.getPrevious());
    // // start.setPrevious(node);

    // // }
    // // else 
    // if(start == null || index == 0){
    // start = node;
    // }
    // else{
    // get(index-1).setNext(node);
    // node.setPrevious(get(index-1));

    // node.setNext(get(index));
    // get(index).setPrevious(node);

    // }
    // size++;
    // }

    public E addFirst(E data){
        Node<E> node = new Node(data);
        if(start != null){
            node.setNext(start);
            node.setPrevious(start.getPrevious());
            start.setPrevious(node);

        }
        start = node;
        size++;
        return (E)data;
    }

    public E addLast(E e){
        Node<E> node = new Node(e);
        if(start == null){
            start = node;
        }
        else{
            node.setNext(start);
            node.setPrevious(start.getPrevious());
            start.getPrevious().setNext(node);
            start.setPrevious(node);
        }  
        size++;
        return e;
    }

    public void delete(int index){
        //get(index).getPrevious() = get(index).getNext();
        //get(index).setNext(get(index).getPrevious());
        getNode(index-1).setNext(getNode(index+1));
        getNode(index+1).setPrevious(getNode(index-1));
        //get(index) = null;
        size--;

    }

    public void deleteFirst(){
        //getFirst().getNext() = getFirst().setPrevious(start.getPrevious());
        getLast().setNext(getNode(1));

        //start.

        start = getNode(1);
        size--;
    }

    public void deleteLast(){
        //getLast();
        getLast().getPrevious().setNext(start);
        start.setPrevious(getLast().getPrevious());
        size--;
    }

    public int size(){
        return size;
    }

    public void clear(){
        for(int i = 0; i<size; i++){
            delete(i);

            size--;
        }
    }
    
    //public DLinkedList returnList(){
        //return DLinkedList;
    //}

    public void contains(){

    }

}
