

import static org.junit.Assert.*;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

/**
 * The test class DLinkedListTest.
 *
 * @author  (your name)
 * @version (a version number or a date)
 */
public class DLinkedListTest
{
    /**
     * Default constructor for test class DLinkedListTest
     */
    public DLinkedListTest()
    {
    }

    /**
     * Sets up the test fixture.
     *
     * Called before every test case method.
     */
    @Before
    public void setUp()
    {
    }

    /**
     * Tears down the test fixture.
     *
     * Called after every test case method.
     */
    @After
    public void tearDown()
    {
    }


    @Test
    public void addFirst()
    {
        DLinkedList<Integer> dLinkedL2 = new DLinkedList<Integer>();
        assertEquals(1, (int)dLinkedL2.addFirst(1));
    }
    
    @Test
    public void getFirst()
    {
        
        DLinkedList<Integer> dLinkedL1 = new DLinkedList<Integer>();
        assertEquals(1, (int)dLinkedL1.add(1, 1));
        assertEquals(1, (int)dLinkedL1.getFirst().getData());
    }

    @Test
    public void addLastandGetLast()
    {
        DLinkedList<Integer> dLinkedL1 = new DLinkedList<Integer>();
        assertEquals(10, (int)dLinkedL1.addLast(10));
        assertEquals(10, (int)dLinkedL1.getLast().getData());
    }
    
    @Test
    public void deleteFirst()
    {
        
        DLinkedList<Integer> dLinkedL1 = new DLinkedList<Integer>();
        dLinkedL1.addFirst(33);
        dLinkedL1.addFirst(32);
        dLinkedL1.deleteFirst();
        assertEquals(33, (int)dLinkedL1.getFirst().getData());
    }
    
    @Test
    public void deleteLast()
    {
        
        DLinkedList<Integer> dLinkedL1 = new DLinkedList<Integer>();
        dLinkedL1.addFirst(33);
        dLinkedL1.addFirst(32);
        dLinkedL1.deleteLast();
        assertEquals(32, (int)dLinkedL1.getLast().getData());
    }
    
    @Test
    public void delete()
    {
        
        DLinkedList<Integer> dLinkedL1 = new DLinkedList<Integer>();
        dLinkedL1.addFirst(3);
        dLinkedL1.addFirst(2);
        dLinkedL1.addFirst(1);
        dLinkedL1.addFirst(0);
        dLinkedL1.delete(2);
        assertEquals(3, (int)dLinkedL1.get(3));
    }
    
    @Test
    public void add()
    {
        
        DLinkedList<Integer> dLinkedL1 = new DLinkedList<Integer>();
        dLinkedL1.add(0, 1);
         dLinkedL1.add(1, 2);
        dLinkedL1.add(2, 3);
         dLinkedL1.add(3, 4);
        
        
        
        
        assertEquals(2, (int)dLinkedL1.get(1));
    }
    
    // @Test
    // public void readFile()
    // {
        
        // DLinkedList<Integer> dLinkedL1 = new DLinkedList<Integer>();
        // dLinkedL1.readFile();
        
        // int[] r = {4, 0, 9, 8, 1, -2, 7, 39};
        
        
        
        // assertEquals(r, dLinkedL1.readFile());
    // }
    
    

    @Test
    public void readFile()
    {
    }
}





