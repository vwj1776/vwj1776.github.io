import java.util.Iterator;
/**
 * Write a description of class ListIterator here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class ListIterator<E> implements Iterator
{
    private Node<E> current;
    private int count = 0;
    private DLinkedList<E> list;
    public ListIterator(){
        current = list.getFirst();
    }

    
    public boolean hasNext(){
        return count < list.size();
    }
    
    public E next(){
        E data = current.getData();
        current = current.getNext();
        count++;
        return data;
    }
    
        
    // public Iterator<E> iterator(){
        // //return new 
    // }
}
