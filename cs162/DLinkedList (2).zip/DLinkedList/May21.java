import java.util.*;
/**
 * Write a description of class May21 here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class May21
{
    // instance variables - replace the example below with your own
    private int x;
    private static int y = 0;
    private ArrayList<Integer> list3;
    private int id;
    
    public static void main(String[] args){
        
    }
    
    
    /**
     * Constructor for objects of class May21
     */
    public May21(int id)
    {
        // initialise instance variables
        this.id = id;
    }
    
    public void printX(){
        System.out.println(x);
    }
    
    public static void printXAlso(){
        //System.out.println(x);
    }
    
    public static void printY(){
        System.out.println(y);
    }
    
    public void setID(int id){
        this.id = id;
    }
    
    public int getID(){
        return id;
    }
    
    private static void test2(){
        ArrayList<May21> list1 = new ArrayList<>();
        list1.add(new May21(4));
        list1.add(new May21(6));
        list1.add(new May21(7));
    }
    
    public static void printList(List list){
        System.out.println(list);
    }
    
    // public String toString(){
        
    // }
    
    private static void test1(){
        ArrayList<Integer> list1 = new ArrayList<>(); // only for local variables
        
        //ArrayList<Integer> list2;
        
        list1.add(3); list1.add(6);
        ArrayList<Integer> list2 = list1;
        
        //list3 = new ArrayList<>(list1);
        
        
        
        
        // printY();
        // May21.printY();
        
        // May21 obj = new May21();
        // obj.printX();
        // obj.y = 99;
    }

}
