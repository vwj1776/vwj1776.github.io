
/**
 * Write a description of class Node here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Node<E>
{
    // instance variables - replace the example below with your own
    private Node<E> next;
    private Node<E> previous;
    private E data;

    /**
     * Constructor for objects of class Node
     */
    public Node (E e){
        data = e;
        next = this;
        previous = this;
        
    }
    
    //public void set(int index){
        
    //}
    
    public void setNext(Node<E> next){
        this.next = next;
    }
    
    public void setPrevious(Node<E> previous){
        this.previous = previous;
    }
    
     public Node<E> getNext(){
        return next;
    }
    
    public Node<E> getPrevious(){
        return previous;
    }
    
    public E getData(){
        return data;
    }
    
    public String toString(Node<E> s){
        return "" + s.getData();
    }
    

}
