import java.io.*;
import java.nio.file.*;
import java.util.*;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.Iterator;
/**
 * Write a description of class ReadFile here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class ReadFile
{
    
    private static String filename = "dintegersfromclass.txt";
    
    
    
    public int[] readInts(String fileName){
        int[] data;
        
        try{
            filename = fileName;
            List<Integer> nums = new ArrayList<>();
            Scanner scanner = new Scanner(Paths.get(filename));
            System.out.println(scanner);
            while(scanner.hasNextInt()){
                nums.add(scanner.nextInt());
            }
            
            data = new int[nums.size()];
            Iterator<Integer> it = nums.iterator();
            int i = 0;
            while(it.hasNext()){
                data[i] = it.next();
                i++;
            }
        }
        catch(IOException e){
            System.out.println("cannot find file " + filename);
            data = new int[0];
        }
        return data;
    }
    
        public String[] readString(){
        String[] data;
        try{
            List<String> nums = new ArrayList<>();
            Scanner scanner = new Scanner(Paths.get(filename));
            System.out.println(scanner);
            while(scanner.hasNextLine()){
                nums.add(scanner.nextLine());
            }
            
            data = new String[nums.size()];
            Iterator<String> it = nums.iterator();
            int i = 0;
            while(it.hasNext()){
                data[i] = it.next();
                i++;
            }
        }
        catch(IOException e){
            System.out.println("cannot find file " + filename);
            data = new String[]{""};
        }
        return data;
    }
}
