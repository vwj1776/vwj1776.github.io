import java.util.*;
/**
 * Write a description of class Tester here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Tester
{
    
    
    public Tester(){
         
   }
   
   public static void main(String[] args){
       ArrayList<Integer> a = new ArrayList<>();
       a.add(4);
       //a.add("hey");
       
       
    }
}
