import java.io.*;
import java.util.*;
/**
 * Write a description of class WriteFile here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class WriteFile
{
        public boolean createFile(String filename, int numEntries)
    {
        boolean success = false;
        
        if(numEntries > 0) {
            try (FileWriter writer = new FileWriter(filename)) {
                String[] entries = new String[numEntries];
                for(int i = 0; i < numEntries; i++) {
                    entries[i] = "" + i;
                }
                //Arrays.sort(entries);
                for(int i = 0; i < numEntries; i++) {
                    writer.write(entries[i] + " ");
                    writer.write('\n');
                }
                
                success = true;
            }
            catch(IOException e) {
                System.err.println("There was a problem writing to " + filename);
            }
                
        }
        return success;
    }
}
